

// Using the Fetch API to get data from the provided JSON endpoint
fetch('https://dummy.restapiexample.com/api/v1/employees/get/json', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        },
    })
       .then(response => response.json())
       .then(response => console.log(JSON.stringify(response)))